import os
import json
import matplotlib.pyplot as plt
from datetime import datetime

repertoire = r'C:\Users\thiba\Desktop\analyse\voiture'
parkings_data = []

# Charger les données de tous les fichiers
for fichier in os.listdir(repertoire):
    if fichier.endswith(".txt"):
        chemin_fichier = os.path.join(repertoire, fichier)

        with open(chemin_fichier, 'r') as file:
            parking_data_list = json.load(file)

        # Imbirquer les données dans des variables
        for parking_data in parking_data_list:
            parking_name = parking_data.get('name', {}).get('value', 0)
            timestamp_str = parking_data['availableSpotNumber']['metadata']['timestamp']['value']
            timestamp = datetime.fromisoformat(timestamp_str)
            date_and_time = timestamp.strftime('%Y-%m-%d %H:%M')
            total_spots = parking_data.get('totalSpotNumber', {}).get('value', 0)
            available_spots = parking_data.get('availableSpotNumber', {}).get('value', 0)

            parking_info = next((p for p in parkings_data if p['name'] == parking_name), None)
            if parking_info is None:
                parking_info = {'name': parking_name, 'dates': [], 'total_spots': [], 'available_spots': []}
                parkings_data.append(parking_info)

            parking_info['dates'].append(date_and_time)
            parking_info['total_spots'].append(total_spots)
            parking_info['available_spots'].append(available_spots)

# Analyse et création de graphiques
for parking_info in parkings_data:
    # Taux de remplissage moyen
    fill_rates = [100 * a / t if t > 0 else 0 for a, t in zip(parking_info['available_spots'], parking_info['total_spots'])]
    plt.figure(figsize=(10, 5))
    plt.plot(parking_info['dates'], fill_rates, label=f"{parking_info['name']} - Taux de remplissage moyen", marker='o')
    plt.xlabel('Date et Heure')
    plt.ylabel('Taux de remplissage (%)')
    plt.title(f'Évolution du taux de remplissage moyen - {parking_info["name"]}')
    plt.xticks(rotation=90)  # Rotation des étiquettes pour une meilleure lisibilité
    plt.legend()
    plt.show()

    # Jours de saturation
    threshold = 90 # Saturation
    saturated_dates = [date for date, fill_rate in zip(parking_info['dates'], fill_rates) if fill_rate > threshold]
    plt.figure(figsize=(10, 5))
    plt.bar(parking_info['dates'], fill_rates, label='Taux de remplissage moyen')
    plt.scatter(saturated_dates, [threshold] * len(saturated_dates), color='red', label='Saturé')
    plt.xlabel('Date et Heure')
    plt.ylabel('Taux de remplissage (%)')
    plt.title('Date de saturation')
    plt.xticks(rotation=45)  # Rotation des étiquettes pour une meilleure lisibilité
    plt.legend()
    plt.show()
