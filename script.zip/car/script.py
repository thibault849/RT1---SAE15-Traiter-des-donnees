from flask import Flask, render_template
import requests
import json
import os
import glob
import schedule
import threading
import time
import signal
from datetime import datetime

app = Flask(__name__)

with open('api.txt', 'r') as file:
    api_url = file.read()

# Définir la durée d'échantillonage (en minutes)
dur_echan = int(input("Veuillez indiquer une durée d'échantillonage (en min) :"))

# Définir le temps d'attente avant la fermeture (en heure)
temps_attente = int(input("Indiquer une durée de fermeture (en heure) : ")) * 3600

# Fonction pour mettre à jour les données à partir de l'API et sauvegarder dans data.txt
def update_data_and_save_to_file():
    try:
        response = requests.get(api_url)
        data = response.json()

        with open('data.txt', 'w') as file:
            json.dump(data, file)

    except requests.exceptions.RequestException as e:
        print(f"Erreur lors de la récupération et de la sauvegarde des données : {e}")

# Fonction pour créer un fichier de sauvegarde distinct toutes les 30 minutes
def backup_data_to_file():
    try:
        response = requests.get(api_url)
        data = response.json()

        # Sauvegarder les nouvelles données dans un fichier de sauvegarde avec un timestamp
        timestamp = datetime.now().strftime("%Y%m%d%H%M%S")
        backup_filename = f'backup/data_backup_{timestamp}.txt'
        with open(backup_filename, 'w') as backup_file:
            json.dump(data, backup_file)

    except requests.exceptions.RequestException as e:
        print(f"Erreur lors de la récupération et de la sauvegarde des données pour la sauvegarde : {e}")

# Fonction pour récupérer les données depuis le fichier data.txt
def read_data_from_file():
    try:
        with open('data.txt', 'r') as file:
            data = json.load(file)
        return data
    except FileNotFoundError:
        return []
    
# Fonction pour compter le nombre de fichier dans le dossier backup    
def count_backup_files():
    try:
        backup_dir = 'backup'
        files = glob.glob(os.path.join(backup_dir, '*.txt'))
        return len(files)
    except Exception as e:
        print(f"Erreur lors du comptage des fichiers de sauvegarde : {e}")
        return 0

# Fonction pour fermer l'application FLASK
def fermer_application():
    print(f"L'application est bien lancée, tout les {dur_echan} un fichier de sauvegarde sera fait. L\'applicaiton se fermera automatiquement dans {temps_attente/3600} heures")
    time.sleep(temps_attente)
    print("Fermeture de l'application...")
    os.kill(os.getpid(), signal.SIGINT)

# Démarrez le thread de fermeture
thread_fermeture = threading.Thread(target=fermer_application)
thread_fermeture.start()

# Afficher les données sur la page web
@app.route('/')
def index():
    # Récupérer les données depuis le fichier
    parking_data = read_data_from_file()
    backup_count = count_backup_files()

     # Modèle HTML avec les données et la date de la dernière mise à jour
    return render_template('index.html', parking_data=parking_data, last_update=datetime.now(), backup_count=backup_count)

def run_continuous_schedule():
    while True:
        schedule.run_pending()
        time.sleep(1)

def run_flask_app():
    app.run(host='91.134.91.9', port=5500, debug=False)

if __name__ == '__main__':
    # Vérifier si le répertoire de sauvegarde existe, sinon le créer
    backup_dir = 'backup'
    if not os.path.exists(backup_dir):
        os.makedirs(backup_dir)

    # Lancer la tâche pour effacer et mettre à jour data.txt toutes les 1 minute
    schedule.every(1).minutes.do(update_data_and_save_to_file)

    # Lancer la tâche de sauvegarde toutes les 30 minutes
    schedule.every(dur_echan).minutes.do(backup_data_to_file)

    # Lancer les tâches en continu dans des threads séparés
    continuous_tasks_thread = threading.Thread(target=run_continuous_schedule)
    continuous_tasks_thread.start()

    flask_app_thread = threading.Thread(target=run_flask_app)
    flask_app_thread.start()

    # Attendre la fin des threads avant de quitter le programme
    continuous_tasks_thread.join()
    flask_app_thread.join()

