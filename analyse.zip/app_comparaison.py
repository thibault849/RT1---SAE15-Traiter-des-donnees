import os
import json
import matplotlib.pyplot as plt
from datetime import datetime

def load_data(directory, vehicle_type):
    data = []

    for filename in os.listdir(directory):
        if filename.endswith(".txt"):
            filepath = os.path.join(directory, filename)
            print(f"Found file: {filepath}")

            with open(filepath, 'r') as file:
                try:
                    parking_data_list = json.load(file)
                except json.JSONDecodeError as e:
                    print(f"Error decoding JSON in file {filepath}: {e}")
                    continue  # Passe au fichier suivant en cas d'erreur

            for parking_data in parking_data_list:
                if vehicle_type == 'car' and 'car_data' in parking_data:
                    data.append(parking_data['car_data'])
                elif vehicle_type == 'bike' and 'bike_data' in parking_data:
                    data.append(parking_data['bike_data'])

    return data

# Reste du code inchangé...


def process_data(data, vehicle_type, tramway_proximity):
    parking_info = {'dates': [], 'total_spots': [], 'available_spots': []}

    for entry in data:
        timestamp_str = entry['metadata']['timestamp']['value']

        if vehicle_type == 'car':
            total_spots = entry['totalSpotNumber']['value']
            available_spots = entry['availableSpotNumber']['value']
        elif vehicle_type == 'bike':
            total_spots = entry.get('totalBikeSpotNumber', 0)
            available_spots = entry.get('availableBikeSpotNumber', 0)

        timestamp = datetime.fromisoformat(timestamp_str)
        date_and_time = timestamp.strftime('%Y-%m-%d %H:%M')

        parking_info['dates'].append(date_and_time)
        parking_info['total_spots'].append(total_spots)
        
        # Si la proximité du tramway est prise en compte, ajustez les places disponibles
        if tramway_proximity and vehicle_type == 'bike':
            available_spots = adjust_bike_spots(available_spots)

        parking_info['available_spots'].append(available_spots)

    return parking_info

def adjust_bike_spots(original_spots):
    # Fonction pour ajuster les places disponibles pour les vélos en fonction de la proximité du tramway
    # Vous pouvez adapter cette fonction en fonction de la logique que vous souhaitez appliquer
    # Pour l'instant, elle renvoie simplement la moitié des places disponibles
    return original_spots // 2

def plot_graphs(parking_info, title):
    fill_rates = [100 * a / t if t > 0 else 0 for a, t in zip(parking_info['available_spots'], parking_info['total_spots'])]
    plt.figure(figsize=(10, 5))
    plt.plot(parking_info['dates'], fill_rates, label=f"{title} - Taux de remplissage moyen", marker='o')
    plt.xlabel('Date et Heure')
    plt.ylabel('Taux de remplissage (%)')
    plt.title(f'Évolution du taux de remplissage moyen - {title}')
    plt.xticks(rotation=90)
    plt.legend()
    plt.show()

# Directory paths for car and bike parking data
car_directory = r'C:\Users\thiba\Desktop\Pour SAE GITHUB\save_fichier\voiture'
bike_directory = r'C:\Users\thiba\Desktop\Pour SAE GITHUB\save_fichier\vélo'

# Load and process car parking data
car_data = load_data(car_directory, 'car')
print("Car Data:", car_data)  # Ajout de cette ligne pour vérifier les données
car_parking_info = process_data(car_data, 'car', tramway_proximity=False)
plot_graphs(car_parking_info, 'Parkings Voitures')

# Load and process bike parking data
bike_data = load_data(bike_directory, 'bike')
print("Bike Data:", bike_data)  # Ajout de cette ligne pour vérifier les données
bike_parking_info = process_data(bike_data, 'bike', tramway_proximity=True)
plot_graphs(bike_parking_info, 'Parkings Vélos')

# Comparing car and bike parking data
plt.figure(figsize=(10, 5))
plt.plot(car_parking_info['dates'], car_parking_info['available_spots'], label='Parkings Voitures', marker='o')
plt.plot(bike_parking_info['dates'], bike_parking_info['available_spots'], label='Parkings Vélos', marker='o')
plt.xlabel('Date et Heure')
plt.ylabel('Nombre de places disponibles')
plt.title('Comparaison des places disponibles dans les parkings Voitures et Vélos')
plt.xticks(rotation=90)
plt.legend()
plt.show()
